from __future__ import annotations

import json
from pathlib import Path

from cases import run_case
from common import DATA_DIR, OUTPUT_DIR, sha256, write_output

CASES = [
    *[f"m1l{i}" for i in range(1, 9)],
    *[f"m2l{i}" for i in range(1, 11)],
    *[f"m3l{i}" for i in range(1, 10)],
    *[f"m4l{i}" for i in range(1, 12)],
    *[f"m5l{i}" for i in range(1, 9)],
    *[f"m6l{i}" for i in range(1, 8)],
]


def main() -> None:
    manifest = json.loads((DATA_DIR / "manifest.json").read_text(encoding="utf-8"))
    for filename, expected in manifest["files"].items():
        actual = sha256(DATA_DIR / filename)
        if actual != expected["sha256"]:
            raise AssertionError(f"Checksum mismatch: {filename}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    first_pass = {}
    for case_id in CASES:
        result = run_case(case_id)
        if not result:
            raise AssertionError(f"Empty result: {case_id}")
        first_pass[case_id] = result
        write_output(case_id, result)

    for case_id in CASES:
        if run_case(case_id) != first_pass[case_id]:
            raise AssertionError(f"Non-deterministic output: {case_id}")

    summary = {"cases": len(CASES), "data_files": len(manifest["files"]), "deterministic": True, "status": "passed"}
    (OUTPUT_DIR / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
